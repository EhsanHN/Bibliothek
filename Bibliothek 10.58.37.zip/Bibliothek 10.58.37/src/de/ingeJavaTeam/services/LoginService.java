package de.ingeJavaTeam.services;

public class LoginService {


    public boolean checkLogin(String username, char[] password) {
        // ToDo return Dao.checkLogin(username, password);
        return true;
    }


}


